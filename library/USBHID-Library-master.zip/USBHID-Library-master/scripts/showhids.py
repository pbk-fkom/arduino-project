from pywinusb import hid

hid.core.show_hids()
