# KRcode-Library
ini adalah Library Arduino yang menyerdahakan pembacaan QR Code dan Barcode Scanner dengan USB Host SHield
